import pandas as pd
import numpy as np
import pickle
import xgboost as xgb
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns


# Load pre-trained models
rf_model_filename = r"D:/ml/final_model.pkl"
with open(rf_model_filename, "rb") as file:
    rf_model = pickle.load(file)
# Load pre-trained model
model_filename =r"D:/ml/diabetes.pkl"
with open(model_filename, "rb") as file:
    diabetes_model = pickle.load(file)

xgb_model_filename = r"D:/ml/project_lung.pkl"
with open(xgb_model_filename, "rb") as model_file:
    loaded_model = pickle.load(model_file)



# Load label encoders for Heart Disease
categorical_columns = ["Gender", "Smoking", "Alcohol Intake", "Family History", "Diabetes",
                       "Obesity", "Exercise Induced Angina", "Chest Pain Type"]
label_encoders = {}
for col in categorical_columns:
    with open(f"{col}_encoder.pkl", "rb") as file:
        label_encoders[col] = pickle.load(file)
def predict_heart_disease(user_input):
    input_data = pd.DataFrame([user_input], columns=categorical_columns)
    prediction = rf_model.predict(input_data)[0]
    probability = rf_model.predict_proba(input_data)[0][1] * 100
    return prediction, probability

diabetes_features = ["Pregnancies", "Glucose", "Blood Pressure", "SkinThickness", "Insulin", "BMI", 
                     "DiabetesPedigreeFunction", "Age"]
def predict_diabetes(user_input):
    input_data = pd.DataFrame([user_input], columns=diabetes_features)
    prediction = diabetes_model.predict(input_data)[0]
    probability = diabetes_model.predict_proba(input_data)[0][1] * 100
    return prediction, probability




# Define features for Lung Disease
lung_features = ["Age", "Smoking", "Genetic Risk", "Dry Cough", "Shortness of Breath", "Chest Pain"]

def predict_lung_disease(user_input):
    input_df = pd.DataFrame([user_input], columns=lung_features)
    dinput = xgb.DMatrix(input_df)
    y_prob = loaded_model.predict(dinput)[0]
    predicted_level = np.argmax(y_prob)
    risk_score = np.max(y_prob)
    return predicted_level, risk_score

# Streamlit Navigation
st.set_page_config(page_title="Disease Prediction", layout="wide")
st.sidebar.image("https://th.bing.com/th/id/OIP.gIfCCCDqYKsYQ7gonoiJYAHaE7?rs=1&pid=ImgDetMain", use_column_width=True)
st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", ["Heart Disease Prediction", "Lung Disease Prediction",  "Diabetes Prediction","Model Performance"])

if page == "Heart Disease Prediction":
    st.title("🫀 Heart Disease Prediction & Risk Estimation")
    st.markdown("### Enter Patient Details Below")
    
    col1, col2 = st.columns(2)
    with col1:
        age = st.slider("Age", 20, 100, 50)
        gender = st.selectbox("Gender", ["Male", "Female"])
        cholesterol = st.number_input("Cholesterol", 100, 300, 200)
        blood_pressure = st.number_input("Blood Pressure", 80, 200, 120)
        heart_rate = st.number_input("Heart Rate", 40, 150, 70)
    
    with col2:
        smoking = st.selectbox("Smoking", ["Never", "Former", "Current"])
        alcohol = st.selectbox("Alcohol Intake", ["None", "Moderate", "Heavy"])
        exercise_hours = st.slider("Exercise Hours per Week", 0, 10, 3)
        family_history = st.selectbox("Family History", ["No", "Yes"])
        diabetes = st.selectbox("Diabetes", ["No", "Yes"])
        obesity = st.selectbox("Obesity", ["No", "Yes"])
        stress_level = st.slider("Stress Level (1-10)", 1, 10, 5)
        blood_sugar = st.number_input("Blood Sugar", 50, 300, 100)
        angina = st.selectbox("Exercise Induced Angina", ["No", "Yes"])
        chest_pain = st.selectbox("Chest Pain Type", ["Typical Angina", "Atypical Angina", "Non-anginal Pain", "Asymptomatic"])
    
    if st.button("Predict Heart Disease"):
        input_data = pd.DataFrame({
            "Age": [age], "Gender": [gender], "Cholesterol": [cholesterol],
            "Blood Pressure": [blood_pressure], "Heart Rate": [heart_rate], "Smoking": [smoking],
            "Alcohol Intake": [alcohol], "Exercise Hours": [exercise_hours], "Family History": [family_history],
            "Diabetes": [diabetes], "Obesity": [obesity], "Stress Level": [stress_level], "Blood Sugar": [blood_sugar],
            "Exercise Induced Angina": [angina], "Chest Pain Type": [chest_pain]
        })
        for col in categorical_columns:
            input_data[col] = label_encoders[col].transform(input_data[col])
        prediction = rf_model.predict(input_data)[0]
        probability = rf_model.predict_proba(input_data)[0][1] * 100
        if prediction == 1:
            st.error(f"⚠ The patient *has heart disease. Risk Factor: **{probability:.2f}%*")
        else:
            st.success(f"✅ The patient *does not have heart disease. Estimated risk: **{probability:.2f}%*")

elif page == "Lung Disease Prediction":
    st.title("🫁 Lung Disease Risk Prediction")
    st.write("Enter patient details to predict lung disease severity.")
    
    age = st.number_input("Age", min_value=1, max_value=100, value=30)
    smoking = st.selectbox("Smoking (0: No, 1: Yes)", [0, 1])
    genetic_risk = st.slider("Genetic Risk (1-7)", 1, 7, 3)
    dry_cough = st.selectbox("Dry Cough (0: No, 1: Yes)", [0, 1])
    shortness_of_breath = st.selectbox("Shortness of Breath (0: No, 1: Yes)", [0, 1])
    chest_pain = st.selectbox("Chest Pain (0: No, 1: Yes)", [0, 1])
    
    if st.button("Predict Lung Disease"):
        user_data = {"Age": age, "Smoking": smoking, "Genetic Risk": genetic_risk,
                     "Dry Cough": dry_cough, "Shortness of Breath": shortness_of_breath, "Chest Pain": chest_pain}
        predicted_level, risk_score = predict_lung_disease(user_data)
        st.subheader("Prediction Results")
        st.write(f"Predicted Disease Severity Level: {predicted_level}")
        st.write(f"Risk Score: {risk_score:.2f}")
elif page == "Diabetes Prediction":
    st.title("Diabetes Prediction & Risk Estimation")
    st.markdown("### Enter Patient Details Below")
    
    # User Inputs
    pregnancies = st.slider("Number of Pregnancies", 0, 20, 2)
    glucose = st.number_input("Glucose Level", 50, 300, 120)
    blood_pressure = st.number_input("Blood Pressure", 50, 200, 80)
    skin_thickness = st.number_input("Skin Thickness", 0, 100, 20)
    insulin = st.number_input("Insulin Level", 0, 900, 100)
    bmi = st.number_input("Body Mass Index (BMI)", 10.0, 60.0, 25.0)
    diabetes_pedigree = st.number_input("Diabetes Pedigree Function", 0.0, 2.5, 0.5)
    age = st.slider("Age", 10, 100, 30)
    
    # Prepare input data
    input_data = pd.DataFrame({
        "Pregnancies": [pregnancies], "Glucose": [glucose], "Blood Pressure": [blood_pressure],
        "SkinThickness": [skin_thickness], "Insulin": [insulin], "BMI": [bmi],
        "DiabetesPedigreeFunction": [diabetes_pedigree], "Age": [age]
    })
    
    # Prediction
    if st.button("Predict"):
        prediction = diabetes_model.predict(input_data)[0]
        probability = diabetes_model.predict_proba(input_data)[0][1] * 100  # Probability of diabetes

        if prediction == 1:
            st.error(f"⚠ The patient has diabetes. Risk Factor: **{probability:.2f}%")
        else:
            st.success(f"✅ The patient does not have diabetes. Estimated risk: **{probability:.2f}%")
elif page == "Model Performance":
    st.title("📌 Feature Importance for heart disease")
    
    # Feature Importance Visualization
    feature_importance = rf_model.feature_importances_
    feature_names = ["Age", "Gender", "Cholesterol", "Blood Pressure", "Heart Rate", "Smoking",
                     "Alcohol Intake", "Exercise Hours", "Family History", "Diabetes", "Obesity",
                     "Stress Level", "Blood Sugar", "Exercise Induced Angina", "Chest Pain Type"]

    feature_df = pd.DataFrame({"Feature": feature_names, "Importance": feature_importance})
    feature_df = feature_df.sort_values(by="Importance", ascending=False)
    
   
    plt.figure(figsize=(10, 6))
    sns.barplot(x="Importance", y="Feature", data=feature_df, palette="viridis")
    plt.xlabel("Feature Importance Score")
    plt.ylabel("Features")
    plt.title("Top Important Features for Prediction")
    st.pyplot(plt)
    st.write("Model trained using Random Forest on a medical dataset for heart disease prediction.")

   
    st.title("📌 Feature Importance for diabetes")
    # Feature Importance Visualization
    feature_importance = diabetes_model.feature_importances_
    feature_names = ["Pregnancies", "Glucose", "Blood Pressure", "SkinThickness", "Insulin", "BMI", 
                     "DiabetesPedigreeFunction", "Age"]
    
    feature_df = pd.DataFrame({"Feature": feature_names, "Importance": feature_importance})
    feature_df = feature_df.sort_values(by="Importance", ascending=False)
    
   
    plt.figure(figsize=(10, 6))
    sns.barplot(x="Importance", y="Feature", data=feature_df, palette="viridis")
    plt.xlabel("Feature Importance Score")
    plt.ylabel("Features")
    plt.title("Top Important Features for Prediction")
    st.pyplot(plt)
    
    st.write("Model trained using Random Forest on a medical dataset for diabetes prediction.")
  
    st.subheader("📌 Feature Importance for lung disease")

    feature_importance =  loaded_model.get_score(importance_type='weight')  # Get feature importance scores
    feature_df = pd.DataFrame({"Feature": list(feature_importance.keys()), 
                           "Importance": list(feature_importance.values())})
    feature_df = feature_df.sort_values(by="Importance", ascending=False)

    plt.figure(figsize=(10, 6))
    sns.barplot(x="Importance", y="Feature", data=feature_df, palette="viridis")
    plt.xlabel("Feature Importance Score")
    plt.ylabel("Features")
    plt.title("Top Important Features for Lung Disease Prediction")
    st.pyplot(plt)